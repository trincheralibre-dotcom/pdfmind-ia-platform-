# ⚡ QUICK START — PDFMind en 5 minutos

## 🎯 Objetivo: Tener PDFMind corriendo localmente

---

## Paso 1: Clonar proyecto

```bash
cd tu-carpeta-proyectos
git clone https://github.com/tu-usuario/pdfmind
cd pdfmind
```

---

## Paso 2: Setup Backend

```bash
cd backend

# Instalar dependencias
npm install

# Crear .env
cp .env.example .env

# Editar .env con tus credenciales
# (por ahora puedes dejar valores dummy para PRUEBA)
nano .env
```

---

## Paso 3: Setup Firebase (5 min)

### En otra terminal:

1. Ve a https://firebase.google.com
2. Crea nuevo proyecto (nombre: "pdfmind-dev")
3. Ve a Project Settings
4. Copia `FIREBASE_PROJECT_ID` y `FIREBASE_AUTH_DOMAIN`
5. Descarga JSON de credenciales en "Service Accounts"
6. Copia el JSON al .env

---

## Paso 4: Setup Claude API (3 min)

1. Ve a https://console.anthropic.com
2. Crea API key
3. Copia a .env en `ANTHROPIC_API_KEY=sk-ant-xxxxx`

---

## Paso 5: Inicia Backend

```bash
cd backend
npm run dev

# ✅ Deberías ver:
# 🚀 PDFMind API corriendo en puerto 5000
# 📍 Local: http://localhost:5000
# ✅ Health check: http://localhost:5000/api/health
```

---

## Paso 6: En otra terminal, inicia Frontend

```bash
cd frontend
npx http-server

# ✅ Abre: http://localhost:8080
```

---

## 🎉 ¡LISTO!

Deberías ver:
- Landing page blanca de PDFMind
- Botón "Subir PDF"
- Botón "Login"
- Secciones de Herramientas, Firma, Precios

---

## 🧪 Testing Rápido

### Test 1: Health Check
```bash
curl http://localhost:5000/api/health
# Respuesta: {"ok":true,...}
```

### Test 2: Registro
```bash
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@test.com",
    "password": "test123",
    "name": "Test"
  }'
# Respuesta: {"success":true,"token":"...","user":{...}}
```

### Test 3: Chat IA
```bash
curl -X POST http://localhost:5000/api/ai/chat \
  -H "Content-Type: application/json" \
  -d '{
    "question": "¿Cuál es el tema de este PDF?",
    "pdfContent": "Esto es un PDF de ejemplo sobre contratos...",
    "email": "test@test.com"
  }'
# Respuesta: {"success":true,"answer":"...","tokensUsed":123}
```

---

## 🚨 Si algo no funciona

### "Cannot find module 'express'"
```bash
cd backend
rm -rf node_modules package-lock.json
npm install
```

### "Firebase credentials not valid"
```bash
# Revisa que .env tenga FIREBASE_PROJECT_ID correcto
# Verifica que Firebase project existe
# Prueba en Firebase console
```

### "ANTHROPIC_API_KEY is missing"
```bash
# Asegúrate de tener API key en .env
# Verifica que no haya espacios: ANTHROPIC_API_KEY=sk-ant-xxxxx
```

### "Port 5000 already in use"
```bash
# Cambiar puerto en .env:
PORT=5001

# O matar proceso:
lsof -i :5000
kill -9 <PID>
```

---

## 📝 Próximos pasos

1. **Conectar Stripe** (para pagos reales)
   - Crea cuenta en stripe.com
   - Copia claves de PRUEBA a .env

2. **Conectar a dominio**
   - Vercel para backend
   - Vercel o Cloudflare para frontend

3. **Cambiar a LIVE**
   - Stripe LIVE keys
   - Firebase producción
   - Deploy a dominio propio

---

¿Problemas? 💬 Abre issue en GitHub o revisa DEPLOY.md
