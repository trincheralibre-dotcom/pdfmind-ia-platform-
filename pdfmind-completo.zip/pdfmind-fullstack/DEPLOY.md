# 🚀 GUÍA DE DEPLOY A PRODUCCIÓN

## Fase 1: Preparación (Hoy)

### 1. Crear cuentas necesarias
- [ ] Firebase (Google Cloud) → https://firebase.google.com
- [ ] Stripe (Pagos) → https://stripe.com
- [ ] Anthropic Claude API → https://console.anthropic.com
- [ ] Vercel o Railway (hosting backend) → https://vercel.com o https://railway.app
- [ ] GitHub (para deploy automático) → https://github.com

### 2. Obtener credenciales

#### Firebase
1. Crear proyecto en Firebase Console
2. Habilitar Authentication (Email/Password + Google)
3. Crear Firestore Database (modo producción)
4. Ir a Project Settings → Service Accounts
5. Generar JSON de credenciales
6. Copiar en .env

#### Stripe
1. Crear cuenta Stripe
2. Ir a Dashboard → API Keys
3. Copiar claves de PRUEBA (.test)
4. Más tarde cambiar a claves LIVE

#### Claude API
1. Crear cuenta en Anthropic
2. Ir a Console → API Keys
3. Generar nueva key
4. Top-up con $5-20

---

## Fase 2: Deploy Backend (1 hora)

### Opción A: Vercel (RECOMENDADO)

```bash
# 1. Instala Vercel CLI
npm i -g vercel

# 2. Login en Vercel
vercel login

# 3. Ve a carpeta backend
cd backend

# 4. Crea vercel.json
cat > vercel.json << 'VERCEL'
{
  "version": 2,
  "builds": [
    { "src": "server.js", "use": "@vercel/node" }
  ],
  "routes": [
    { "src": "/(.*)", "dest": "server.js" }
  ],
  "env": {
    "NODE_ENV": "production"
  }
}
VERCEL

# 5. Deploy
vercel --prod

# ✅ URL: algo-123.vercel.app
```

### Opción B: Railway

```bash
# 1. Instala Railway CLI
npm i -g @railway/cli

# 2. Login
railway login

# 3. Deploy
cd backend
railway up

# ✅ Se abre automático en railway.app
```

### Opción C: Servidor propio (DigitalOcean)

```bash
# 1. SSH a servidor
ssh root@tu-servidor-ip

# 2. Instala Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# 3. Clona proyecto
git clone https://github.com/tu-usuario/pdfmind
cd pdfmind/backend

# 4. Instala PM2 para mantener vivo el servicio
npm i -g pm2
npm install
pm2 start server.js --name pdfmind
pm2 startup
pm2 save

# 5. Configura nginx (reverse proxy)
sudo apt-get install nginx
sudo nano /etc/nginx/sites-available/default

# En el archivo:
server {
  listen 80;
  server_name tu-dominio.com;

  location / {
    proxy_pass http://localhost:5000;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection 'upgrade';
    proxy_set_header Host $host;
    proxy_cache_bypass $http_upgrade;
  }
}

# 6. Reinicia nginx
sudo systemctl restart nginx
```

---

## Fase 3: Deploy Frontend (30 minutos)

### Opción A: Vercel (Mismo lugar que backend)

```bash
cd frontend

# Crear vercel.json
cat > vercel.json << 'VERCEL'
{
  "buildCommand": "",
  "outputDirectory": "."
}
VERCEL

# Deploy
vercel --prod

# ✅ URL: tu-pdfmind.vercel.app
```

### Opción B: GitHub Pages (GRATIS)

```bash
# 1. Sube proyecto a GitHub
git push origin main

# 2. Ve a Settings → Pages
# 3. Selecciona "Deploy from a branch"
# 4. Rama: main, carpeta: /frontend

# ✅ URL: tu-usuario.github.io/pdfmind
```

### Opción C: Cloudflare Pages (RECOMENDADO)

```bash
# 1. Conecta GitHub en Cloudflare Pages
# 2. Selecciona el repo
# 3. Build Command: (dejar vacío)
# 4. Output Directory: frontend

# ✅ URL: pdfmind.pages.dev (o dominio propio)
```

---

## Fase 4: Conectar Frontend + Backend

Edita `/frontend/index.html` y busca todas las URLs de API:

```javascript
// Buscar por: http://localhost:5000
// Reemplazar por: https://tu-backend-url.vercel.app
// O tu URL de producción
```

Lugares a cambiar:
1. Fetch calls en JavaScript
2. Variable `API_URL` si existe
3. Endpoints en funciones de auth, checkout, ai

---

## Fase 5: Configurar Dominio

### Si compraste dominio en GoDaddy:

```bash
# 1. Ve a GoDaddy → DNS Management
# 2. Añade registros A:
   
   Type: A
   Name: @
   Value: IP de tu servidor
   TTL: 1 hour

# 3. O para Vercel/Railway/Cloudflare:
   
   Type: CNAME
   Name: @
   Value: tu-app.vercel.app
   TTL: 1 hour

# 4. Espera 24 horas para que se propague

# 5. Verifica: ping tu-dominio.com
```

### SSL Certificate (GRATIS con Let's Encrypt):

```bash
# Si usas Vercel/Cloudflare: automático ✅

# Si usas servidor propio:
sudo apt-get install certbot python3-certbot-nginx
sudo certbot --nginx -d tu-dominio.com

# Responde las preguntas y ya está
```

---

## Fase 6: Cambiar a Stripe LIVE

**⚠️ Cuando estés 100% seguro:**

```bash
# 1. Ve a Stripe Dashboard
# 2. Settings → API Keys
# 3. Copia las claves LIVE (empiezan con sk_live_)
# 4. Actualiza .env en producción

STRIPE_SECRET_KEY=sk_live_xxxxx
STRIPE_PUBLISHABLE_KEY=pk_live_xxxxx

# 5. Descubre tu Webhook Secret en:
# https://dashboard.stripe.com/webhooks
# Busca tu endpoint POST /api/checkout/webhook

# 6. Copia en .env y reinicia servidor

# ✅ Ahora los pagos son REALES
```

---

## Fase 7: Configurar Variables en Producción

### Vercel:
```bash
# Settings → Environment Variables
# Añade todas las de .env
```

### Railway:
```bash
# Variables tab
# Pega todo el contenido de .env
```

### Servidor propio:
```bash
# Sube .env a servidor:
scp .env root@tu-servidor:/app/

# O crea en servidor:
ssh root@tu-servidor
nano /app/.env
# Pega credenciales
```

---

## Fase 8: Testing (Antes de anunciar)

### Checklist final:

```bash
# ✅ Salud del servidor
curl https://tu-api.vercel.app/api/health

# ✅ Registro funciona
POST /api/auth/register
{
  "email": "test@example.com",
  "password": "test123",
  "name": "Test User"
}

# ✅ Pago en modo prueba
Usa tarjeta: 4242 4242 4242 4242
Cualquier fecha futura
Cualquier CVC (ej: 123)

# ✅ Chat IA funciona
POST /api/ai/chat
{
  "question": "Hola",
  "pdfContent": "Test",
  "email": "test@example.com"
}

# ✅ Upload de archivo
POST /api/files/upload
Archivo: PDF test
Email: test@example.com

# ✅ Frontend carga sin errores
Abre https://tu-pdfmind.com
Abre console (F12)
No debe haber errores rojos
```

---

## Fase 9: Monitoreo

### Activar logs

```bash
# Vercel: Settings → Function Logs
# Railway: Logs tab
# Servidor: tail -f /var/log/pm2-logfile
```

### Monitorear errores

```bash
# Sentry (ERROR TRACKING)
npm i @sentry/node

# En server.js:
import * as Sentry from "@sentry/node";
Sentry.init({
  dsn: "tu-sentry-dsn"
});
```

### Alertas

```bash
# UptimeRobot (monitorear disponibilidad)
1. Ve a uptimerobot.com
2. Añade monitor: https://tu-api.com/api/health
3. Configura alert por email
```

---

## Checklist de Lanzamiento

- [ ] Backend deployado y funcionando
- [ ] Frontend accesible en dominio propio
- [ ] Firebase credenciales en producción
- [ ] Stripe en LIVE (con todas las keys)
- [ ] Claude API con saldo
- [ ] SSL certificate configurado
- [ ] Tests completados
- [ ] Analytics (Google Analytics 4) instalado
- [ ] Email funciona
- [ ] Logs configurados
- [ ] Monitoreo activo
- [ ] Terms of Service actualizado
- [ ] Privacy Policy visible
- [ ] GDPR compliance configurado

---

## 🎉 ¡LANZAMIENTO!

```bash
# Publica en Twitter/LinkedIn
echo "🚀 PDFMind IA está vivo!"
echo "🤖 Chat con PDFs con inteligencia artificial"
echo "📄 25+ herramientas PDF"
echo "💳 Plan gratuito disponible"
echo "🔗 tu-dominio.com"
```

---

## 🆘 Si algo falla

### Backend no responde
```bash
# Vercel
vercel logs --prod

# Railway
railway logs

# Servidor propio
pm2 logs pdfmind
```

### Stripe webhooks no funcionan
```bash
# Vercel: Settings → Serverless Function Logs
# Railway: Logs
# Servidor: tail -f logs/webhook.log
```

### Firebase auth no funciona
```bash
# Verifica CORS en backend
# Verifica credenciales en .env
# Revisa Firebase console > Authentication > Settings
```

### API lenta
```bash
# Verifica logs de Claude API
# Revisa Firebase read/write operations
# Activa caching si es posible
```

---

¡Ahora a **cambiar el mundo de los PDFs!** 🌍📄
