import express from 'express';
import Stripe from 'stripe';
import admin from 'firebase-admin';

const router = express.Router();
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
const db = admin.firestore();

const PLANS = {
  free: { name: 'Gratuito', price: 0, iva: 0, total: 0 },
  pro: { name: 'Plan Pro', price: 900, iva: 189, total: 1089 }, // en cents
  business: { name: 'Plan Business', price: 2900, iva: 609, total: 3509 },
  agencia: { name: 'Plan Agencia', price: 9900, iva: 2079, total: 11979 }
};

// Create payment intent
router.post('/create-payment-intent', async (req, res) => {
  try {
    const { plan, email } = req.body;

    if (!plan || !PLANS[plan]) {
      return res.status(400).json({ error: 'Plan inválido' });
    }

    if (plan === 'free') {
      return res.status(400).json({ error: 'El plan gratuito no requiere pago' });
    }

    const planData = PLANS[plan];

    const paymentIntent = await stripe.paymentIntents.create({
      amount: planData.total,
      currency: 'eur',
      metadata: { plan, email },
      description: `PDFMind ${planData.name}`,
      receipt_email: email
    });

    res.json({
      success: true,
      clientSecret: paymentIntent.client_secret,
      plan: planData
    });
  } catch (error) {
    console.error('❌ Payment intent error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Confirm payment
router.post('/confirm-payment', async (req, res) => {
  try {
    const { paymentIntentId, email } = req.body;

    const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);

    if (paymentIntent.status === 'succeeded') {
      // Update user plan in Firestore
      const plan = paymentIntent.metadata.plan;
      await db.collection('users').doc(email).update({
        plan,
        subscriptionId: paymentIntent.id,
        subscriptionDate: new Date(),
        updatedAt: new Date()
      });

      // Create invoice record
      await db.collection('invoices').add({
        email,
        plan,
        amount: paymentIntent.amount / 100,
        currency: paymentIntent.currency,
        status: 'paid',
        date: new Date(),
        paymentIntentId
      });

      res.json({
        success: true,
        message: 'Pago confirmado y plan activado',
        plan
      });
    } else {
      res.status(400).json({ error: 'Pago no completado' });
    }
  } catch (error) {
    console.error('❌ Confirm payment error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Webhook para actualizaciones automáticas
router.post('/webhook', express.raw({ type: 'application/json' }), async (req, res) => {
  const sig = req.headers['stripe-signature'];

  try {
    const event = stripe.webhooks.constructEvent(
      req.body,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET
    );

    console.log(`📧 Webhook recibido: ${event.type}`);

    switch (event.type) {
      case 'payment_intent.succeeded':
        const { metadata, id } = event.data.object;
        console.log(`✅ Pago exitoso: ${metadata.plan} para ${metadata.email}`);
        
        await db.collection('users').doc(metadata.email).update({
          plan: metadata.plan,
          subscriptionId: id,
          lastPayment: new Date()
        });
        break;

      case 'payment_intent.payment_failed':
        console.log(`❌ Pago fallido: ${event.data.object.id}`);
        break;

      case 'customer.subscription.deleted':
        console.log(`🔕 Suscripción cancelada: ${event.data.object.id}`);
        break;
    }

    res.json({ received: true });
  } catch (error) {
    console.error('❌ Webhook error:', error);
    res.status(400).send(`Webhook Error: ${error.message}`);
  }
});

// Get user plan
router.get('/plan/:email', async (req, res) => {
  try {
    const { email } = req.params;
    const userDoc = await db.collection('users').doc(email).get();

    if (!userDoc.exists) {
      return res.status(404).json({ error: 'Usuario no encontrado' });
    }

    const user = userDoc.data();
    res.json({
      email: user.email,
      plan: user.plan,
      subscriptionDate: user.subscriptionDate
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router;
