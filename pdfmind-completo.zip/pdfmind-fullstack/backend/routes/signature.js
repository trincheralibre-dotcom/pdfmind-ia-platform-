import express from 'express';
import multer from 'multer';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import crypto from 'crypto';
import PDFDocument from 'pdfkit';
import PDFParser from 'pdf-parse';
import admin from 'firebase-admin';
import nodemailer from 'nodemailer';
import { v4 as uuidv4 } from 'uuid';

const router = express.Router();
const db = admin.firestore();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const uploadsDir = path.join(__dirname, '../uploads');

// Email config
const emailTransporter = nodemailer.createTransport({
  host: process.env.EMAIL_HOST,
  port: process.env.EMAIL_PORT,
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

const upload = multer({
  dest: uploadsDir,
  limits: { fileSize: 50 * 1024 * 1024 }
});

// ============================================================================
// REQUEST SIGNATURE - Solicitar firmas por email
// ============================================================================
router.post('/request', upload.single('file'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No file' });

    const { email, signers, message = '', requesterName = 'Unknown' } = req.body;

    if (!signers || signers.length === 0) {
      return res.status(400).json({ error: 'Se requieren firmantes' });
    }

    const fileId = uuidv4();
    const requestId = uuidv4();
    const expiryDate = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000); // 30 días

    console.log(`📝 Requesting signatures from ${signers.length} signers`);

    // Save file in Firestore
    await db.collection('signature_requests').doc(requestId).set({
      fileId,
      requesterId: email,
      requesterName,
      fileName: req.file.originalname,
      fileSize: req.file.size,
      signers: signers.map(s => ({
        email: s,
        status: 'pending',
        signedAt: null,
        signature: null
      })),
      message,
      status: 'pending',
      createdAt: new Date(),
      expiresAt: expiryDate,
      signedDocument: null,
      auditTrail: [
        {
          action: 'request_created',
          timestamp: new Date(),
          actor: email
        }
      ]
    });

    // Save original file
    const originalPath = path.join(uploadsDir, `${fileId}-original.pdf`);
    fs.copyFileSync(req.file.path, originalPath);

    // Send emails to signers
    for (const signer of signers) {
      const signLink = `${process.env.API_URL}/api/signature/sign/${requestId}/${signer}`;

      await emailTransporter.sendMail({
        from: process.env.EMAIL_FROM,
        to: signer,
        subject: `${requesterName} solicita tu firma en: ${req.file.originalname}`,
        html: `
          <h2>Solicitud de Firma Digital</h2>
          <p><strong>${requesterName}</strong> solicita tu firma en el siguiente documento:</p>
          <p><strong>Archivo:</strong> ${req.file.originalname}</p>
          ${message ? `<p><strong>Mensaje:</strong> ${message}</p>` : ''}
          <p>
            <a href="${signLink}" style="background: #0066cc; color: white; padding: 10px 20px; border-radius: 5px; text-decoration: none; display: inline-block;">
              Firmar Documento
            </a>
          </p>
          <p>Este enlace expira en 30 días.</p>
          <hr>
          <p><small>Firma digital eIDAS - PDFMind IA</small></p>
        `
      });

      console.log(`✉️ Email sent to ${signer}`);
    }

    res.json({
      success: true,
      requestId,
      fileId,
      signers: signers.length,
      expiresAt: expiryDate,
      status: 'Solicitud enviada'
    });

    // Cleanup
    fs.unlinkSync(req.file.path);
  } catch (error) {
    console.error('❌ Request signature error:', error);
    res.status(500).json({ error: error.message });
  }
});

// ============================================================================
// SIGN DOCUMENT - Firmar documento (dibujado o certificado)
// ============================================================================
router.post('/sign/:requestId/:signer', async (req, res) => {
  try {
    const { requestId, signer } = req.params;
    const { signatureData, signatureType = 'drawn' } = req.body; // drawn, typed, certificate

    console.log(`✍️ Signing document with ${signatureType} signature`);

    // Get request
    const requestDoc = await db.collection('signature_requests').doc(requestId).get();
    if (!requestDoc.exists) {
      return res.status(404).json({ error: 'Signature request not found' });
    }

    const requestData = requestDoc.data();
    const signerIndex = requestData.signers.findIndex(s => s.email === signer);

    if (signerIndex === -1) {
      return res.status(403).json({ error: 'Unauthorized signer' });
    }

    if (requestData.signers[signerIndex].status !== 'pending') {
      return res.status(400).json({ error: 'Ya fue firmado' });
    }

    // Create timestamp & hash para audit trail
    const timestamp = new Date();
    const signatureHash = crypto.createHash('sha256').update(signatureData + timestamp.toISOString()).digest('hex');

    // Update signer status
    requestData.signers[signerIndex].status = 'signed';
    requestData.signers[signerIndex].signedAt = timestamp;
    requestData.signers[signerIndex].signature = {
      type: signatureType,
      hash: signatureHash,
      timestamp,
      ipAddress: req.ip,
      userAgent: req.get('user-agent')
    };

    // Add audit trail
    requestData.auditTrail.push({
      action: 'signed',
      timestamp,
      actor: signer,
      signatureHash
    });

    // Check if all signed
    const allSigned = requestData.signers.every(s => s.status === 'signed');
    if (allSigned) {
      requestData.status = 'completed';
      requestData.completedAt = timestamp;

      // Generate final signed document
      const originalPath = path.join(uploadsDir, `${requestData.fileId}-original.pdf`);
      const signedPath = path.join(uploadsDir, `${requestData.fileId}-signed.pdf`);

      const dataBuffer = fs.readFileSync(originalPath);
      const pdfData = await PDFParser(dataBuffer);

      const doc = new PDFDocument();
      const output = fs.createWriteStream(signedPath);
      doc.pipe(output);

      // Original content
      doc.text(pdfData.text.substring(0, 3000), { fontSize: 10 });

      // Signature page
      doc.addPage();
      doc.fontSize(16).text('Firma Digital eIDAS', { align: 'center' });
      doc.fontSize(10).text(`\n`);

      // Signers list
      for (const signer of requestData.signers) {
        doc.text(`✓ ${signer.email}`, {
          align: 'left'
        });
        doc.text(`  Firmado: ${signer.signedAt.toLocaleString()}`, {
          fontSize: 8,
          color: '#666'
        });
      }

      doc.fontSize(8);
      doc.text(`\nDocumento sellado digitalmente: ${signatureHash.substring(0, 16)}...`);
      doc.text(`Timestamp: ${timestamp.toISOString()}`);
      doc.text(`Certificado eIDAS-compliant`);

      doc.end();

      await new Promise((resolve, reject) => {
        output.on('finish', resolve);
        output.on('error', reject);
      });

      requestData.signedDocument = `${requestData.fileId}-signed.pdf`;

      // Email to requester
      await emailTransporter.sendMail({
        from: process.env.EMAIL_FROM,
        to: requestData.requesterId,
        subject: `✓ Documento firmado: ${requestData.fileName}`,
        html: `
          <h2>Documento Completamente Firmado</h2>
          <p>El documento <strong>${requestData.fileName}</strong> ha sido firmado por todos los firmantes.</p>
          <p><strong>Firmantes:</strong></p>
          <ul>
            ${requestData.signers.map(s => `<li>${s.email} - ${s.signedAt.toLocaleString()}</li>`).join('')}
          </ul>
          <p>Hash verificado: ${signatureHash.substring(0, 32)}...</p>
          <p><strong>Nivel de firma:</strong> eIDAS Nivel 2 (Firma Electrónica Avanzada)</p>
        `
      });
    }

    // Update Firestore
    await db.collection('signature_requests').doc(requestId).update({
      signers: requestData.signers,
      status: requestData.status,
      completedAt: requestData.completedAt,
      auditTrail: requestData.auditTrail,
      signedDocument: requestData.signedDocument
    });

    res.json({
      success: true,
      status: requestData.status,
      message: allSigned ? 'Todos han firmado. Documento completado.' : 'Firma registrada'
    });
  } catch (error) {
    console.error('❌ Sign error:', error);
    res.status(500).json({ error: error.message });
  }
});

// ============================================================================
// GET REQUEST STATUS - Ver estado de firmas
// ============================================================================
router.get('/status/:requestId', async (req, res) => {
  try {
    const { requestId } = req.params;

    const requestDoc = await db.collection('signature_requests').doc(requestId).get();
    if (!requestDoc.exists) {
      return res.status(404).json({ error: 'Request not found' });
    }

    const data = requestDoc.data();

    res.json({
      success: true,
      requestId,
      status: data.status,
      fileName: data.fileName,
      requesterName: data.requesterName,
      signers: data.signers.map(s => ({
        email: s.email,
        status: s.status,
        signedAt: s.signedAt
      })),
      createdAt: data.createdAt,
      expiresAt: data.expiresAt,
      completedAt: data.completedAt,
      auditTrail: data.auditTrail
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ============================================================================
// DOWNLOAD SIGNED - Descargar documento firmado
// ============================================================================
router.get('/download-signed/:fileId', async (req, res) => {
  try {
    const { fileId } = req.params;
    const filepath = path.join(uploadsDir, `${fileId}-signed.pdf`);

    if (!fs.existsSync(filepath)) {
      return res.status(404).json({ error: 'Signed document not found' });
    }

    res.download(filepath, `${fileId}-signed.pdf`);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ============================================================================
// VERIFY SIGNATURE - Verificar autenticidad de firma
// ============================================================================
router.post('/verify', async (req, res) => {
  try {
    const { requestId, signatureHash } = req.body;

    if (!requestId || !signatureHash) {
      return res.status(400).json({ error: 'Missing parameters' });
    }

    const requestDoc = await db.collection('signature_requests').doc(requestId).get();
    if (!requestDoc.exists) {
      return res.status(404).json({ error: 'Request not found' });
    }

    const data = requestDoc.data();
    const isValid = data.auditTrail.some(entry => 
      entry.signatureHash === signatureHash && entry.action === 'signed'
    );

    res.json({
      success: true,
      valid: isValid,
      status: data.status,
      completedAt: data.completedAt,
      signerCount: data.signers.length,
      signersSigned: data.signers.filter(s => s.status === 'signed').length
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ============================================================================
// BATCH SIGN - Múltiples signatarios simultáneos
// ============================================================================
router.post('/batch-sign', async (req, res) => {
  try {
    const { requestId, signerEmail, signatures } = req.body;

    console.log(`📋 Batch signing ${signatures.length} documents`);

    const batchId = uuidv4();
    const timestamp = new Date();

    // Save batch
    await db.collection('signature_batches').doc(batchId).set({
      requestId,
      signerEmail,
      documentCount: signatures.length,
      status: 'completed',
      timestamp,
      signatures: signatures.map(sig => ({
        documentId: sig.documentId,
        hash: crypto.createHash('sha256').update(sig.data + timestamp.toISOString()).digest('hex'),
        timestamp
      }))
    });

    res.json({
      success: true,
      batchId,
      documentsProcessed: signatures.length,
      status: 'All documents signed'
    });
  } catch (error) {
    console.error('❌ Batch sign error:', error);
    res.status(500).json({ error: error.message });
  }
});

export default router;
