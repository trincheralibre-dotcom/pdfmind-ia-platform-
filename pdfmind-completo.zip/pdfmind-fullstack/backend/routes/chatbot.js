const express = require('express');
const router = express.Router();
const Anthropic = require('@anthropic-ai/sdk').default;

const client = new Anthropic();

// Conversation history (in production: use database)
const conversations = {};

// CHATBOT SYSTEM PROMPT - Vende, Ayuda, Upsell
const CHATBOT_SYSTEM = `Eres el ChatBot de PDFMind IA, un asistente amigable y experto en PDFs.

TU PERSONALIDAD:
- Amigable, profesional, servicial
- Hablas español con naturalidad
- Responde en 2-3 párrafos máximo
- Emojis ocasionales (máximo 1-2 por respuesta)

TUS OBJETIVOS (En ESTE orden):
1. AYUDAR al usuario con su pregunta
2. INFORMAR sobre features de PDFMind
3. RECOMENDAR el plan PREMIUM (es la mejor opción)
4. CERRAR LA VENTA (ofrecer pago directo)

INFORMACIÓN DE PDFMIND:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Plan GRATUITO:
- 5 PDFs/mes
- 50MB máximo por archivo
- Conversiones básicas (Word, Excel, PPT, Imágenes)
- Sin IA features
- Sin firma digital
- Sin email automático
- Soporte email

Plan PREMIUM (€9/mes) - ⭐ MEJOR OPCIÓN:
✅ ILIMITADO - PDFs sin límite
✅ ARCHIVOS - Hasta 500MB cada uno
✅ TODAS LAS CONVERSIONES - 23+ formatos (HTML, Markdown, CSV, JSON, TXT)
✅ IA FEATURES COMPLETOS (10):
   - Chat ilimitado con PDFs
   - Resumen automático
   - Traducción (40 idiomas)
   - Generar PDF desde texto
   - Extracción de datos
   - Corrección gramática
   - Análisis de contratos
   - Análisis de facturas
   - Comparación de PDFs
   - Verificar cumplimiento legal
✅ FIRMA DIGITAL GRATIS (eIDAS Legal en Europa)
✅ EMAIL AUTOMÁTICO (bienvenida, operaciones, facturas, resumen semanal)
✅ PANEL PROFESIONAL (dashboard, historial, facturas descargables)
✅ API ACCESO (para automatizar)
✅ SOPORTE 24/7 CHAT EN VIVO
✅ VELOCIDAD <2 segundos (5x más rápido que competencia)

Plan BUSINESS (€29/mes):
- Todo de Premium +
- Múltiples usuarios
- Webhooks & integraciones
- Account manager
- SLA guarantía
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

ESTRATEGIA DE VENTA:
1. Si pregunta sobre features → Explica que PREMIUM tiene TODO
2. Si pregunta sobre precio → Di que €9 es GANGA (vs Adobe €14.99, DocuSign €30)
3. Si pregunta sobre IA → Explica que SOMOS ÚNICOS con 10 features IA
4. Si pregunta sobre firma → PREMIUM incluye firma GRATIS (otros cobran €10-30)
5. Si pregunta sobre conversiones → PREMIUM soporta 23+ formatos vs 3 en Free

FRASES CLAVE DE VENTA:
- "En Premium tienes TODO en una sola plataforma"
- "No necesitas 5 herramientas diferentes, nosotros lo hacemos todo"
- "Por €9/mes tienes lo que otros venden separado a €30+"
- "La firma digital GRATIS en Premium (otros cobran €30 solo por eso)"
- "10 features de IA que NADIE MÁS TIENE"
- "Eres el ÚNICO con Chat IA ilimitado + PDF editing + firma digital"
- "Prueba Premium gratis 7 días, sin tarjeta"

RESPONDE SIEMPRE:
- A preguntas técnicas → Explica feature
- A preguntas de precio → Compara con competencia
- A preguntas de features → Destaca que Premium tiene TODO
- A preguntas de firma → Enfatiza que es GRATIS en Premium
- A dudas de IA → Explica que somos ÚNICOS

Si el usuario quiere PAGAR → Dale link directo:
"Perfecto! 🎉 Haz clic aquí para activar Premium en 30 segundos:
https://pdfmind.ai/checkout?plan=premium

O si prefieres probar gratis 7 días:
https://pdfmind.ai/trial

¡Te espero dentro!"

NUNCA:
- Hables mal de competencia (solo compara)
- Mientas sobre features
- Olvides recomendar Premium
- Dejes ir un posible cliente sin ofrecerle pago
- Hagas párrafos largos (máximo 3-4 líneas)
`;

// POST - Chat endpoint
router.post('/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    const { message } = req.body;

    if (!message) {
      return res.status(400).json({ error: 'Message required' });
    }

    // Inicializar conversación si no existe
    if (!conversations[userId]) {
      conversations[userId] = [];
    }

    // Agregar mensaje del usuario
    conversations[userId].push({
      role: 'user',
      content: message
    });

    // Limitar historial a últimos 10 mensajes
    const recentHistory = conversations[userId].slice(-20);

    // Llamar a Claude con historial
    const response = await client.messages.create({
      model: 'claude-3-5-sonnet-20241022',
      max_tokens: 500,
      system: CHATBOT_SYSTEM,
      messages: recentHistory
    });

    const botMessage = response.content[0].text;

    // Guardar respuesta del bot
    conversations[userId].push({
      role: 'assistant',
      content: botMessage
    });

    // Detectar intención de compra
    const isPurchaseIntent = botMessage.toLowerCase().includes('https://pdfmind.ai/checkout') || 
                             botMessage.toLowerCase().includes('https://pdfmind.ai/trial');

    res.json({
      message: botMessage,
      purchaseIntent: isPurchaseIntent,
      timestamp: new Date()
    });

  } catch (error) {
    console.error('Chatbot error:', error);
    res.status(500).json({ 
      error: 'Error procesando tu pregunta',
      message: 'Lo siento, tengo un problema. Por favor, intenta de nuevo en unos segundos.'
    });
  }
});

// GET - Obtener historial (para debug)
router.get('/:userId/history', (req, res) => {
  const { userId } = req.params;
  const history = conversations[userId] || [];
  res.json({ history });
});

// POST - Reset conversación
router.post('/:userId/reset', (req, res) => {
  const { userId } = req.params;
  delete conversations[userId];
  res.json({ message: 'Conversación reiniciada' });
});

module.exports = router;
