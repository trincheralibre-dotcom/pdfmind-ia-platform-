import express from 'express';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcrypt';
import admin from 'firebase-admin';

const router = express.Router();

// Firebase initialization
const db = admin.firestore();

// Register
router.post('/register', async (req, res) => {
  try {
    const { email, password, name } = req.body;

    if (!email || !password || !name) {
      return res.status(400).json({ error: 'Email, contraseña y nombre requeridos' });
    }

    // Check if user exists
    const userDoc = await db.collection('users').doc(email).get();
    if (userDoc.exists) {
      return res.status(400).json({ error: 'El usuario ya existe' });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create user in Firestore
    await db.collection('users').doc(email).set({
      name,
      email,
      password: hashedPassword,
      plan: 'free',
      createdAt: new Date(),
      updatedAt: new Date()
    });

    // Create JWT
    const token = jwt.sign(
      { email, plan: 'free', name },
      process.env.JWT_SECRET,
      { expiresIn: '30d' }
    );

    res.status(201).json({
      success: true,
      token,
      user: { email, name, plan: 'free' }
    });
  } catch (error) {
    console.error('❌ Register error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email y contraseña requeridos' });
    }

    // Get user from Firestore
    const userDoc = await db.collection('users').doc(email).get();
    if (!userDoc.exists) {
      return res.status(401).json({ error: 'Credenciales inválidas' });
    }

    const user = userDoc.data();

    // Verify password
    const isValidPassword = await bcrypt.compare(password, user.password);
    if (!isValidPassword) {
      return res.status(401).json({ error: 'Credenciales inválidas' });
    }

    // Create JWT
    const token = jwt.sign(
      { email, plan: user.plan, name: user.name },
      process.env.JWT_SECRET,
      { expiresIn: '30d' }
    );

    res.json({
      success: true,
      token,
      user: { email: user.email, name: user.name, plan: user.plan }
    });
  } catch (error) {
    console.error('❌ Login error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Google OAuth (simulado - en producción usar Firebase Auth)
router.post('/google', async (req, res) => {
  try {
    const { idToken } = req.body;

    // En producción, verificar el token de Google
    // const ticket = await client.verifyIdToken({ idToken });
    // const payload = ticket.getPayload();

    // Para demo, crear usuario automáticamente
    const email = `demo-${Date.now()}@google.com`;
    const name = 'Usuario Demo';

    const token = jwt.sign(
      { email, plan: 'free', name },
      process.env.JWT_SECRET,
      { expiresIn: '30d' }
    );

    res.json({
      success: true,
      token,
      user: { email, name, plan: 'free' }
    });
  } catch (error) {
    console.error('❌ Google auth error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Verify token
router.post('/verify', async (req, res) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];

    if (!token) {
      return res.status(401).json({ error: 'Token no proporcionado' });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    res.json({ valid: true, user: decoded });
  } catch (error) {
    res.status(401).json({ valid: false, error: 'Token inválido' });
  }
});

export default router;
