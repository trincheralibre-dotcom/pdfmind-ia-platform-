import express from 'express';
import multer from 'multer';
import admin from 'firebase-admin';
import PDFParser from 'pdf-parse';
import PDFDocument from 'pdfkit';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const router = express.Router();
const db = admin.firestore();
const storage = admin.storage();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const uploadsDir = path.join(__dirname, '../uploads');

// Ensure uploads directory exists
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Configure multer
const upload = multer({
  dest: uploadsDir,
  limits: { fileSize: 50 * 1024 * 1024 }, // 50MB
  fileFilter: (req, file, cb) => {
    const allowedMimes = [
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'application/vnd.ms-powerpoint',
      'application/vnd.openxmlformats-officedocument.presentationml.presentation',
      'image/jpeg',
      'image/png'
    ];

    if (allowedMimes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Formato de archivo no permitido'));
    }
  }
});

// Upload file
router.post('/upload', upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'Archivo no proporcionado' });
    }

    const { email } = req.body;
    const file = req.file;
    const fileId = `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

    console.log(`📤 Archivo recibido: ${file.originalname} (${file.size} bytes)`);

    // Extract text from PDF if applicable
    let extractedText = '';
    if (file.mimetype === 'application/pdf') {
      try {
        const dataBuffer = fs.readFileSync(file.path);
        const data = await PDFParser(dataBuffer);
        extractedText = data.text;
      } catch (error) {
        console.warn('⚠️ No se pudo extraer texto del PDF:', error.message);
        extractedText = '';
      }
    }

    // Save file metadata to Firestore
    if (email) {
      await db.collection('files').doc(fileId).set({
        email,
        filename: file.originalname,
        mimetype: file.mimetype,
        size: file.size,
        path: file.path,
        uploadedAt: new Date(),
        textExtracted: extractedText ? true : false,
        status: 'ready'
      });
    }

    res.json({
      success: true,
      fileId,
      filename: file.originalname,
      size: file.size,
      textExtracted: extractedText !== '',
      text: extractedText.substring(0, 5000) // Return first 5000 chars
    });
  } catch (error) {
    console.error('❌ Upload error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Get file
router.get('/:fileId', async (req, res) => {
  try {
    const { fileId } = req.params;

    const fileDoc = await db.collection('files').doc(fileId).get();
    if (!fileDoc.exists) {
      return res.status(404).json({ error: 'Archivo no encontrado' });
    }

    const fileData = fileDoc.data();
    res.json({
      success: true,
      file: fileData
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// List files for user
router.get('/user/:email', async (req, res) => {
  try {
    const { email } = req.params;

    const filesSnapshot = await db.collection('files')
      .where('email', '==', email)
      .orderBy('uploadedAt', 'desc')
      .limit(50)
      .get();

    const files = filesSnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    }));

    res.json({
      success: true,
      count: files.length,
      files
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Compress PDF (demo - en producción usar GhostScript)
router.post('/compress', async (req, res) => {
  try {
    const { fileId, email } = req.body;

    const fileDoc = await db.collection('files').doc(fileId).get();
    if (!fileDoc.exists) {
      return res.status(404).json({ error: 'Archivo no encontrado' });
    }

    // En producción: usar ghostscript o similar
    // Para demo: simular compresión
    const originalSize = fileDoc.data().size;
    const compressedSize = Math.floor(originalSize * 0.6); // 60% del original

    await db.collection('conversions').add({
      email,
      sourceFileId: fileId,
      type: 'compress',
      originalSize,
      compressedSize,
      compression: Math.round((1 - compressedSize / originalSize) * 100),
      date: new Date()
    });

    res.json({
      success: true,
      originalSize,
      compressedSize,
      compression: Math.round((1 - compressedSize / originalSize) * 100),
      message: `✅ Comprimido de ${(originalSize / 1024 / 1024).toFixed(2)}MB a ${(compressedSize / 1024 / 1024).toFixed(2)}MB`
    });
  } catch (error) {
    console.error('❌ Compress error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Merge PDFs (demo)
router.post('/merge', async (req, res) => {
  try {
    const { fileIds, email } = req.body;

    if (!fileIds || fileIds.length < 2) {
      return res.status(400).json({ error: 'Se requieren al menos 2 archivos' });
    }

    // Verify all files exist
    for (const fileId of fileIds) {
      const doc = await db.collection('files').doc(fileId).get();
      if (!doc.exists || doc.data().email !== email) {
        return res.status(403).json({ error: 'Acceso denegado a uno de los archivos' });
      }
    }

    // En producción: merge PDFs reales
    const mergedFileId = `merged-${Date.now()}`;

    await db.collection('files').doc(mergedFileId).set({
      email,
      filename: `merged-${Date.now()}.pdf`,
      mimetype: 'application/pdf',
      sourceFiles: fileIds,
      mergedAt: new Date(),
      status: 'ready'
    });

    res.json({
      success: true,
      fileId: mergedFileId,
      filename: `merged-${Date.now()}.pdf`,
      message: '✅ PDFs fusionados correctamente'
    });
  } catch (error) {
    console.error('❌ Merge error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Convert PDF to Word (demo)
router.post('/to-word', async (req, res) => {
  try {
    const { fileId, email } = req.body;

    const fileDoc = await db.collection('files').doc(fileId).get();
    if (!fileDoc.exists) {
      return res.status(404).json({ error: 'Archivo no encontrado' });
    }

    // En producción: convertir real con Cloudinary
    const wordFileId = `${fileId}-docx`;

    await db.collection('conversions').add({
      email,
      sourceFileId: fileId,
      type: 'pdf-to-word',
      outputFormat: 'docx',
      date: new Date()
    });

    res.json({
      success: true,
      fileId: wordFileId,
      filename: `${fileDoc.data().filename.replace('.pdf', '')}.docx`,
      format: 'docx',
      message: '✅ Convertido a Word'
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Delete file
router.delete('/:fileId', async (req, res) => {
  try {
    const { fileId } = req.params;
    const { email } = req.body;

    const fileDoc = await db.collection('files').doc(fileId).get();
    if (!fileDoc.exists) {
      return res.status(404).json({ error: 'Archivo no encontrado' });
    }

    if (fileDoc.data().email !== email) {
      return res.status(403).json({ error: 'Acceso denegado' });
    }

    // Delete from filesystem
    try {
      fs.unlinkSync(fileDoc.data().path);
    } catch (e) {
      // Archivo no existe en filesystem
    }

    // Delete from Firestore
    await db.collection('files').doc(fileId).delete();

    res.json({ success: true, message: 'Archivo eliminado' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router;
