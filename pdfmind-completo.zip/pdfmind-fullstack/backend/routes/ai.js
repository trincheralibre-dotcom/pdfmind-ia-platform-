import express from 'express';
import Anthropic from '@anthropic-ai/sdk';
import admin from 'firebase-admin';

const router = express.Router();
const client = new Anthropic();
const db = admin.firestore();

// Middleware to verify user
const verifyUser = async (req, res, next) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) throw new Error('Token no proporcionado');

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (error) {
    res.status(401).json({ error: 'Token inválido' });
  }
};

// Chat con PDF
router.post('/chat', async (req, res) => {
  try {
    const { question, pdfContent, email } = req.body;

    if (!question || !pdfContent) {
      return res.status(400).json({ error: 'Pregunta y contenido PDF requeridos' });
    }

    console.log(`🤖 Chat IA: "${question.substring(0, 50)}..."`);

    const message = await client.messages.create({
      model: 'claude-opus-4-20250805',
      max_tokens: 1024,
      messages: [
        {
          role: 'user',
          content: `Eres un asistente experto en análisis de documentos PDF. Responde en español.

DOCUMENTO PDF:
${pdfContent.substring(0, 8000)}

PREGUNTA DEL USUARIO:
${question}

Responde de forma clara, concisa y directa. Si la información no está en el documento, dilo explícitamente.`
        }
      ]
    });

    const answer = message.content[0].text;

    // Save chat history
    if (email) {
      await db.collection('chats').add({
        email,
        type: 'chat',
        question,
        answer,
        tokensUsed: message.usage.output_tokens,
        date: new Date()
      });
    }

    res.json({
      success: true,
      answer,
      tokensUsed: message.usage.output_tokens
    });
  } catch (error) {
    console.error('❌ Chat error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Resumen ejecutivo
router.post('/resumen', async (req, res) => {
  try {
    const { pdfContent, email } = req.body;

    if (!pdfContent) {
      return res.status(400).json({ error: 'Contenido PDF requerido' });
    }

    console.log('📄 Generando resumen IA...');

    const message = await client.messages.create({
      model: 'claude-opus-4-20250805',
      max_tokens: 1500,
      messages: [
        {
          role: 'user',
          content: `Eres un experto en crear resúmenes ejecutivos. Analiza este documento y crea un resumen en español con esta estructura:

DOCUMENTO:
${pdfContent.substring(0, 10000)}

ESTRUCTURA REQUERIDA:
1. **TÍTULO**: Una línea con el tema principal
2. **RESUMEN EJECUTIVO**: 3-4 líneas max
3. **📌 PUNTOS CLAVE**: 5-7 bullet points
4. **⚠️ ATENCIÓN**: Cualquier riesgo o cláusula importante
5. **✅ CONCLUSIÓN**: Recomendación final

Sé conciso y directo. Usa formato markdown.`
        }
      ]
    });

    const summary = message.content[0].text;

    // Save
    if (email) {
      await db.collection('chats').add({
        email,
        type: 'resumen',
        summary,
        tokensUsed: message.usage.output_tokens,
        date: new Date()
      });
    }

    res.json({
      success: true,
      summary,
      tokensUsed: message.usage.output_tokens
    });
  } catch (error) {
    console.error('❌ Summary error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Traducción
router.post('/traducir', async (req, res) => {
  try {
    const { pdfContent, targetLang = 'español', email } = req.body;

    if (!pdfContent) {
      return res.status(400).json({ error: 'Contenido PDF requerido' });
    }

    console.log(`🌍 Traduciendo a ${targetLang}...`);

    const message = await client.messages.create({
      model: 'claude-opus-4-20250805',
      max_tokens: 2000,
      messages: [
        {
          role: 'user',
          content: `Traduce el siguiente documento al ${targetLang} MANTENIENDO EXACTAMENTE:
- Formato y estructura
- Énfasis y cursivas
- Listas y viñetas
- Números y cifras

DOCUMENTO ORIGINAL:
${pdfContent.substring(0, 10000)}

Proporciona SOLO el documento traducido, sin explicaciones.`
        }
      ]
    });

    const translated = message.content[0].text;

    if (email) {
      await db.collection('chats').add({
        email,
        type: 'traducir',
        targetLang,
        tokensUsed: message.usage.output_tokens,
        date: new Date()
      });
    }

    res.json({
      success: true,
      translated,
      targetLang,
      tokensUsed: message.usage.output_tokens
    });
  } catch (error) {
    console.error('❌ Translation error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Generar PDF con IA
router.post('/generar', async (req, res) => {
  try {
    const { prompt, email } = req.body;

    if (!prompt) {
      return res.status(400).json({ error: 'Descripción requerida' });
    }

    console.log(`✨ Generando documento con IA...`);

    const message = await client.messages.create({
      model: 'claude-opus-4-20250805',
      max_tokens: 2500,
      messages: [
        {
          role: 'user',
          content: `Crea un documento profesional en español basado en esta descripción:

"${prompt}"

INSTRUCCIONES:
1. Usa formato markdown con encabezados
2. Incluye secciones claras y bien estructuradas
3. Añade un título profesional
4. Organiza con listas cuando sea apropiado
5. Listo para convertir a PDF

Proporciona el contenido completo del documento.`
        }
      ]
    });

    const content = message.content[0].text;

    if (email) {
      await db.collection('generados').add({
        email,
        prompt,
        content,
        date: new Date()
      });
    }

    res.json({
      success: true,
      content,
      canDownload: true
    });
  } catch (error) {
    console.error('❌ Generation error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Extraer datos (tablas, fechas, importes)
router.post('/extraer', async (req, res) => {
  try {
    const { pdfContent, email } = req.body;

    if (!pdfContent) {
      return res.status(400).json({ error: 'Contenido PDF requerido' });
    }

    console.log('🔍 Extrayendo datos...');

    const message = await client.messages.create({
      model: 'claude-opus-4-20250805',
      max_tokens: 1500,
      messages: [
        {
          role: 'user',
          content: `Extrae TODOS los datos importantes de este documento en formato JSON:

DOCUMENTO:
${pdfContent.substring(0, 8000)}

EXTRAE:
- dates: [todas las fechas encontradas]
- numbers: [números y cifras importantes]
- companies: [nombres de empresas]
- emails: [direcciones de email]
- phone: [números de teléfono]
- amounts: [importes y precios]
- tables: [datos de tablas en formato legible]

Responde SOLO con JSON válido, sin explicaciones.`
        }
      ]
    });

    const jsonText = message.content[0].text;
    let extractedData = {};

    try {
      extractedData = JSON.parse(jsonText);
    } catch {
      extractedData = { raw: jsonText };
    }

    if (email) {
      await db.collection('extracciones').add({
        email,
        data: extractedData,
        date: new Date()
      });
    }

    res.json({
      success: true,
      data: extractedData,
      format: 'JSON'
    });
  } catch (error) {
    console.error('❌ Extraction error:', error);
    res.status(500).json({ error: error.message });
  }
});

export default router;
