import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import authRoutes from './routes/auth.js';
import checkoutRoutes from './routes/checkout.js';
import aiRoutes from './routes/ai.js';
import filesRoutes from './routes/files.js';
import pdfRoutes from './routes/pdf-processing.js';
import signatureRoutes from './routes/signature.js';

dotenv.config();

const app = express();

// Security middleware
app.use(helmet());

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutos
  max: 100 // limit each IP to 100 requests per windowMs
});
app.use('/api/', limiter);

// CORS
app.use(cors({
  origin: process.env.ALLOWED_ORIGINS?.split(',') || '*',
  credentials: true
}));

// Body parsers
app.use(express.json({ limit: '100mb' }));
app.use(express.urlencoded({ limit: '100mb', extended: true }));

// ============================================================================
// HEALTH & STATUS
// ============================================================================
app.get('/api/health', (req, res) => {
  res.json({ 
    ok: true, 
    timestamp: new Date().toISOString(),
    version: '2.0.0',
    features: [
      'auth',
      'payments',
      'ai',
      'pdf-processing',
      'e-signature',
      'multilingual'
    ]
  });
});

app.get('/api/status', (req, res) => {
  res.json({
    api: 'online',
    database: 'connected',
    features: {
      auth: '✅',
      payments: '✅',
      ai: '✅',
      pdf: '✅',
      signature: '✅'
    }
  });
});

// ============================================================================
// API ROUTES
// ============================================================================

// Authentication
app.use('/api/auth', authRoutes);

// Payments
app.use('/api/checkout', checkoutRoutes);

// AI Features
app.use('/api/ai', aiRoutes);

// File Management
app.use('/api/files', filesRoutes);

// PDF Processing (REAL)
app.use('/api/pdf', pdfRoutes);

// E-Signature (eIDAS compliant)
app.use('/api/signature', signatureRoutes);

// ============================================================================
// ERROR HANDLING
// ============================================================================
app.use((err, req, res, next) => {
  console.error('❌ ERROR:', err.message);
  res.status(err.status || 500).json({
    error: err.message,
    status: err.status || 500,
    timestamp: new Date().toISOString()
  });
});

// 404 Handler
app.use((req, res) => {
  res.status(404).json({ 
    error: 'Endpoint no encontrado', 
    path: req.path,
    hint: 'Revisa /api/health para endpoints disponibles'
  });
});

// ============================================================================
// START SERVER
// ============================================================================
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`
╔════════════════════════════════════════════════════════════════╗
║                    🚀 PDFMind API v2.0.0                      ║
╚════════════════════════════════════════════════════════════════╝

✅ Auth:           /api/auth/*
✅ Payments:       /api/checkout/*
✅ AI Features:    /api/ai/*
✅ File Upload:    /api/files/*
✅ PDF Tools:      /api/pdf/* (REAL)
✅ E-Signature:    /api/signature/* (eIDAS)
✅ Health:         /api/health
✅ Status:         /api/status

📍 Local: http://localhost:${PORT}
🔗 API URL: ${process.env.API_URL || `http://localhost:${PORT}`}

Ready to dominate PDFs globally! 🌍
  `);
});
