import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

app.use(express.json());
app.use(cors());

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date(), message: '✅ Server running!' });
});

// Chatbot endpoint
app.post('/api/chatbot/:userId', (req, res) => {
  const { userId } = req.params;
  const { message } = req.body;

  if (!message) {
    return res.status(400).json({ error: 'Message required' });
  }

  const responses = {
    'features': 'PDFMind tiene 120+ features! ✅ PDF editing (merge, split, compress), 10 features IA (chat, resumen, traducción), firma digital GRATIS, 23+ conversiones...',
    'precio': 'Planes: GRATIS (5 PDFs/mes), PREMIUM €9/mes (TODO ilimitado + IA + firma), BUSINESS €29/mes (enterprise). ¿Quieres activar Premium? https://pdfmind.ai/checkout',
    'ia': 'Tenemos 10 features IA ÚNICOS: Chat ilimitado, Resumen, Traducción (40 idiomas), Generar PDF, Extracción datos, Corrección, Análisis contratos, Facturas, Comparación, Cumplimiento legal.',
    'firma': 'Firma digital eIDAS Level 2 - ¡GRATIS en Premium! (Otros cobran €10-30). Válido legalmente en Europa, múltiples signatarios, timestamp.',
    'hola': '¡Hola! 👋 Soy tu asistente de PDFMind. ¿Dudas sobre features, precio, IA, o firma? Pregunta lo que quieras!',
  };

  let botMessage = '¡Excelente pregunta! 🎉 ';

  const msgLower = message.toLowerCase();
  for (const [key, value] of Object.entries(responses)) {
    if (msgLower.includes(key)) {
      botMessage = value;
      break;
    }
  }

  if (botMessage === '¡Excelente pregunta! 🎉 ') {
    botMessage = `Gracias por tu pregunta sobre "${message}". Te recomiendo que pruebes Premium por €9/mes. Tienes TODO integrado en una plataforma. ¿Quieres saber más? https://pdfmind.ai/trial`;
  }

  res.json({
    message: botMessage,
    purchaseIntent: botMessage.includes('https://'),
    timestamp: new Date()
  });
});

app.listen(PORT, () => {
  console.log(`\n✅ Server running on http://localhost:${PORT}`);
  console.log(`📍 Health check: http://localhost:${PORT}/api/health`);
  console.log(`🤖 Chatbot endpoint: POST http://localhost:${PORT}/api/chatbot/{userId}\n`);
});
