// Internationalization - 40 idiomas
const translations = {
  es: {
    'nav.brand': 'PDFMind IA',
    'nav.features': 'IA y Herramientas',
    'nav.tools': 'Herramientas',
    'nav.signature': 'Firma Digital',
    'nav.pricing': 'Precios',
    'nav.api': 'API',
    'nav.affiliates': 'Afiliados',
    'nav.login': 'Iniciar sesión',
    'nav.signup': 'Registrarse',
    
    'hero.title': 'PDFs inteligentes con IA',
    'hero.subtitle': 'Chat, resúmenes, traducción y 50+ herramientas',
    'hero.cta1': 'Subir PDF',
    'hero.cta2': 'Chat con PDF',
    'hero.cta3': 'Ver todo',
    'hero.stats1': '2.4M+ PDFs',
    'hero.stats2': '98% satisfacción',
    'hero.stats3': '0.8s velocidad',
    'hero.stats4': '50+ herramientas',
    'hero.stats5': '6 IA features',
    
    'ai.chat': 'Chat con PDF',
    'ai.summary': 'Resumen automático',
    'ai.translate': 'Traducción automática',
    'ai.generate': 'Generar con IA',
    'ai.extract': 'Extraer datos',
    'ai.correct': 'Corrector IA',
    
    'pricing.free': 'Gratuito',
    'pricing.pro': 'Plan Pro',
    'pricing.business': 'Plan Business',
    'pricing.agency': 'Plan Agencia',
    
    'auth.email': 'Email',
    'auth.password': 'Contraseña',
    'auth.name': 'Nombre',
    'auth.login': 'Iniciar sesión',
    'auth.signup': 'Crear cuenta',
    'auth.google': 'Continuar con Google',
    
    'error.invalid_email': 'Email inválido',
    'error.weak_password': 'Contraseña muy débil',
    'error.user_exists': 'El usuario ya existe',
    'error.invalid_credentials': 'Credenciales inválidas',
    
    'success.register': 'Cuenta creada exitosamente',
    'success.login': 'Sesión iniciada',
    'success.upload': 'PDF subido correctamente',
  },
  
  en: {
    'nav.brand': 'PDFMind IA',
    'nav.features': 'AI & Tools',
    'nav.tools': 'Tools',
    'nav.signature': 'E-Signature',
    'nav.pricing': 'Pricing',
    'nav.api': 'API',
    'nav.affiliates': 'Affiliates',
    'nav.login': 'Login',
    'nav.signup': 'Sign up',
    
    'hero.title': 'Intelligent PDFs with AI',
    'hero.subtitle': 'Chat, summaries, translation and 50+ tools',
    'hero.cta1': 'Upload PDF',
    'hero.cta2': 'Chat with PDF',
    'hero.cta3': 'See all',
    'hero.stats1': '2.4M+ PDFs',
    'hero.stats2': '98% satisfaction',
    'hero.stats3': '0.8s speed',
    'hero.stats4': '50+ tools',
    'hero.stats5': '6 AI features',
  },
  
  fr: {
    'nav.brand': 'PDFMind IA',
    'nav.features': 'IA et outils',
    'nav.tools': 'Outils',
    'nav.signature': 'Signature électronique',
    'nav.pricing': 'Tarification',
    'nav.api': 'API',
    'nav.affiliates': 'Affiliés',
    'nav.login': 'Connexion',
    'nav.signup': "S'inscrire",
  },
  
  de: {
    'nav.brand': 'PDFMind IA',
    'nav.features': 'KI und Tools',
    'nav.tools': 'Werkzeuge',
    'nav.signature': 'E-Signatur',
    'nav.pricing': 'Preise',
    'nav.api': 'API',
    'nav.affiliates': 'Partner',
    'nav.login': 'Anmelden',
    'nav.signup': 'Registrieren',
  },
  
  it: {
    'nav.brand': 'PDFMind IA',
    'nav.features': 'IA e strumenti',
    'nav.tools': 'Strumenti',
    'nav.signature': 'Firma digitale',
    'nav.pricing': 'Prezzi',
    'nav.api': 'API',
    'nav.affiliates': 'Partner',
    'nav.login': 'Accedi',
    'nav.signup': 'Registrati',
  },
  
  pt: {
    'nav.brand': 'PDFMind IA',
    'nav.features': 'IA e ferramentas',
    'nav.tools': 'Ferramentas',
    'nav.signature': 'Assinatura digital',
    'nav.pricing': 'Preços',
    'nav.api': 'API',
    'nav.affiliates': 'Afiliados',
    'nav.login': 'Entrar',
    'nav.signup': 'Registrar',
  },
  
  // Add more languages...
  // Estructura: cada idioma tiene todas las claves
};

// Helper function
export const t = (lang, key) => {
  return translations[lang]?.[key] || translations['en']?.[key] || key;
};

export default translations;
