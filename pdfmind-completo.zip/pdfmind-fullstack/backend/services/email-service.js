/**
 * Email Service - Complete email functionality
 */

const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  host: process.env.EMAIL_HOST || 'smtp.gmail.com',
  port: process.env.EMAIL_PORT || 587,
  secure: false,
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

// WELCOME EMAIL
const sendWelcomeEmail = async (email, name, plan) => {
  const htmlContent = `
    <!DOCTYPE html>
    <html>
    <head><style>
      body{font-family:'Inter',sans-serif;background:#0d0d0d;color:#f5f5f5}
      .container{max-width:600px;margin:0 auto;padding:2rem}
      .header{background:linear-gradient(135deg,#c9a84c,#e5c879);padding:2rem;border-radius:12px;text-align:center;margin-bottom:2rem}
      .header h1{color:#0d0d0d;margin:0;font-size:2rem}
      .content{background:#1a1a1a;padding:2rem;border-radius:12px;border:1px solid rgba(201,168,76,0.15)}
      .btn{display:inline-block;background:linear-gradient(135deg,#c9a84c,#e5c879);color:#0d0d0d;padding:0.75rem 1.5rem;border-radius:8px;text-decoration:none;font-weight:600;margin:1rem 0}
    </style></head>
    <body>
      <div class="container">
        <div class="header"><h1>¡Bienvenido a PDFMind IA!</h1></div>
        <div class="content">
          <h2>Hola ${name},</h2>
          <p>¡Gracias por registrarte! Tu Plan: <strong>${plan}</strong></p>
          <p>Ahora puedes:</p>
          <ul>
            <li>💬 Chat con PDFs</li>
            <li>📄 Resumir documentos</li>
            <li>🌐 Traducir a 40+ idiomas</li>
            <li>✨ Generar PDFs con IA</li>
            <li>✍️ Firmar digitalmente</li>
            <li>📁 Editar PDFs completo</li>
          </ul>
          <a href="https://pdfmind.ai/dashboard" class="btn">Acceder a tu Dashboard</a>
        </div>
      </div>
    </body>
    </html>
  `;

  try {
    await transporter.sendMail({
      from: process.env.EMAIL_FROM || 'noreply@pdfmind.ai',
      to: email,
      subject: `¡Bienvenido a PDFMind IA, ${name}! 🎉`,
      html: htmlContent
    });
    return true;
  } catch (error) {
    console.error(`Error sending welcome email: ${error.message}`);
    return false;
  }
};

// EMAIL VERIFICATION
const sendVerificationEmail = async (email, verificationCode) => {
  const htmlContent = `
    <!DOCTYPE html>
    <html><head><style>
      body{font-family:'Inter',sans-serif;background:#0d0d0d;color:#f5f5f5}
      .container{max-width:600px;margin:0 auto;padding:2rem}
      .code-box{background:#1a1a1a;padding:2rem;text-align:center;border-radius:12px;border:2px solid #c9a84c;margin:2rem 0}
      .code{font-size:2rem;font-weight:900;color:#e5c879;letter-spacing:2px}
    </style></head>
    <body>
      <div class="container">
        <h2>Verifica tu email</h2>
        <p>Usa este código para verificar tu cuenta:</p>
        <div class="code-box"><div class="code">${verificationCode}</div></div>
        <p>Este código expira en 24 horas.</p>
      </div>
    </body></html>
  `;

  try {
    await transporter.sendMail({
      from: process.env.EMAIL_FROM || 'noreply@pdfmind.ai',
      to: email,
      subject: 'Verifica tu email - PDFMind IA',
      html: htmlContent
    });
    return true;
  } catch (error) {
    console.error(`Error: ${error.message}`);
    return false;
  }
};

// PASSWORD RESET
const sendPasswordResetEmail = async (email, resetLink) => {
  const htmlContent = `
    <!DOCTYPE html>
    <html><head><style>
      body{font-family:'Inter',sans-serif;background:#0d0d0d;color:#f5f5f5}
      .container{max-width:600px;margin:0 auto;padding:2rem}
      .btn{display:inline-block;background:linear-gradient(135deg,#c9a84c,#e5c879);color:#0d0d0d;padding:0.75rem 1.5rem;border-radius:8px;text-decoration:none;font-weight:600;margin:1rem 0}
    </style></head>
    <body>
      <div class="container">
        <h2>Recuperar contraseña</h2>
        <p>Haz clic en el botón para cambiar tu contraseña (válido 1 hora):</p>
        <a href="${resetLink}" class="btn">Cambiar Contraseña</a>
        <p>Si no lo solicitaste, ignora este email.</p>
      </div>
    </body></html>
  `;

  try {
    await transporter.sendMail({
      from: process.env.EMAIL_FROM || 'noreply@pdfmind.ai',
      to: email,
      subject: 'Recupera tu contraseña - PDFMind IA',
      html: htmlContent
    });
    return true;
  } catch (error) {
    console.error(`Error: ${error.message}`);
    return false;
  }
};

// OPERATION COMPLETE
const sendOperationCompleteEmail = async (email, operationType, fileName, downloadLink) => {
  const htmlContent = `
    <!DOCTYPE html>
    <html><head><style>
      body{font-family:'Inter',sans-serif;background:#0d0d0d;color:#f5f5f5}
      .container{max-width:600px;margin:0 auto;padding:2rem}
      .success-box{background:#1a1a1a;padding:2rem;border-radius:12px;border-left:4px solid #10b981}
      .btn{display:inline-block;background:#10b981;color:white;padding:0.75rem 1.5rem;border-radius:8px;text-decoration:none;font-weight:600;margin:1rem 0}
    </style></head>
    <body>
      <div class="container">
        <div class="success-box">
          <h2>✅ ${operationType} Completado</h2>
          <p><strong>Archivo:</strong> ${fileName}</p>
          <a href="${downloadLink}" class="btn">⬇️ Descargar</a>
        </div>
      </div>
    </body></html>
  `;

  try {
    await transporter.sendMail({
      from: process.env.EMAIL_FROM || 'noreply@pdfmind.ai',
      to: email,
      subject: `✅ ${operationType} Completado - PDFMind IA`,
      html: htmlContent
    });
    return true;
  } catch (error) {
    console.error(`Error: ${error.message}`);
    return false;
  }
};

// INVOICE EMAIL
const sendInvoiceEmail = async (email, invoiceNumber, amount) => {
  const htmlContent = `
    <!DOCTYPE html>
    <html><head><style>
      body{font-family:'Inter',sans-serif;background:#0d0d0d;color:#f5f5f5}
      .container{max-width:600px;margin:0 auto;padding:2rem}
      .invoice-box{background:#1a1a1a;padding:2rem;border-radius:12px;border:1px solid rgba(201,168,76,0.15)}
      .invoice-amount{font-size:2rem;font-weight:900;color:#e5c879}
    </style></head>
    <body>
      <div class="container">
        <h2>Tu Factura #${invoiceNumber}</h2>
        <div class="invoice-box">
          <p>Gracias por tu suscripción a PDFMind Pro.</p>
          <div class="invoice-amount">€${amount}</div>
          <p>Puedes descargar tu factura desde tu dashboard.</p>
        </div>
      </div>
    </body></html>
  `;

  try {
    await transporter.sendMail({
      from: process.env.EMAIL_FROM || 'noreply@pdfmind.ai',
      to: email,
      subject: `Factura #${invoiceNumber} - PDFMind IA`,
      html: htmlContent
    });
    return true;
  } catch (error) {
    console.error(`Error: ${error.message}`);
    return false;
  }
};

// WEEKLY SUMMARY
const sendWeeklySummaryEmail = async (email, name, stats) => {
  const htmlContent = `
    <!DOCTYPE html>
    <html><head><style>
      body{font-family:'Inter',sans-serif;background:#0d0d0d;color:#f5f5f5}
      .container{max-width:600px;margin:0 auto;padding:2rem}
      .stat-card{background:#1a1a1a;padding:1rem;margin:0.5rem 0;border-radius:8px;border-left:3px solid #c9a84c}
      .stat-value{font-size:1.5rem;font-weight:700;color:#e5c879}
    </style></head>
    <body>
      <div class="container">
        <h2>Tu resumen semanal, ${name}</h2>
        <div class="stat-card">
          <div>PDFs Procesados</div>
          <div class="stat-value">${stats.files || 0}</div>
        </div>
        <div class="stat-card">
          <div>Operaciones IA</div>
          <div class="stat-value">${stats.operations || 0}</div>
        </div>
        <div class="stat-card">
          <div>Espacio Usado</div>
          <div class="stat-value">${stats.space || '0 GB'}</div>
        </div>
      </div>
    </body></html>
  `;

  try {
    await transporter.sendMail({
      from: process.env.EMAIL_FROM || 'noreply@pdfmind.ai',
      to: email,
      subject: `Tu resumen semanal - PDFMind IA`,
      html: htmlContent
    });
    return true;
  } catch (error) {
    console.error(`Error: ${error.message}`);
    return false;
  }
};

module.exports = {
  sendWelcomeEmail,
  sendVerificationEmail,
  sendPasswordResetEmail,
  sendOperationCompleteEmail,
  sendInvoiceEmail,
  sendWeeklySummaryEmail,
  transporter
};
