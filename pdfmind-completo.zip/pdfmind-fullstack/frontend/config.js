// PDFMind Frontend Configuration
// Change API_URL to your production backend URL

const API_URL = window.location.hostname === 'localhost' 
  ? 'http://localhost:5000'
  : 'https://tu-backend-url.vercel.app'; // Change this!

// Export for use in HTML
window.CONFIG = {
  API_URL,
  STRIPE_PUBLIC_KEY: 'pk_test_xxxxx', // Change to your Stripe key
  PLANS: {
    free: { name: 'Gratuito', price: 0, features: 5 },
    pro: { name: 'Pro', price: 9, features: 'unlimited' },
    business: { name: 'Business', price: 29, features: 'unlimited' },
    agencia: { name: 'Agencia', price: 99, features: 'unlimited' }
  }
};
