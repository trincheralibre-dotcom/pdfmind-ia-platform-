/**
 * PDFMind IA v2.0 - Frontend Feature Management
 * Todas las features de PDF, IA y firma digital
 */

const FEATURES = {
  // IA Features (6)
  ai: {
    chat: {
      name: 'Chat con PDF',
      icon: '💬',
      description: 'Pregunta lo que quieras sobre el PDF',
      tokens: 1024,
      price: 'Pro',
      category: 'ai'
    },
    summary: {
      name: 'Resumen Automático',
      icon: '📄',
      description: '5 puntos clave del documento',
      tokens: 1500,
      price: 'Pro',
      category: 'ai'
    },
    translate: {
      name: 'Traducción IA',
      icon: '🌐',
      description: '40+ idiomas manteniendo formato',
      tokens: 2000,
      price: 'Pro',
      category: 'ai'
    },
    generate: {
      name: 'Generar con IA',
      icon: '✨',
      description: 'Crear PDFs desde descripción',
      tokens: 2500,
      price: 'Pro',
      category: 'ai'
    },
    extract: {
      name: 'Extraer a JSON',
      icon: '📊',
      description: 'Datos estructurados automáticos',
      tokens: 1500,
      price: 'Pro',
      category: 'ai'
    },
    correct: {
      name: 'Corrector IA',
      icon: '✏️',
      description: 'Gramática, ortografía, estilo',
      tokens: 1800,
      price: 'Pro',
      category: 'ai'
    }
  },

  // PDF Tools (20+)
  pdf: {
    compress: {
      name: 'Comprimir PDF',
      icon: '📦',
      description: 'Reduce 60% sin perder calidad',
      price: 'Gratuito',
      category: 'convert'
    },
    merge: {
      name: 'Fusionar PDFs',
      icon: '📎',
      description: 'Combina múltiples en uno',
      price: 'Gratuito',
      category: 'edit'
    },
    split: {
      name: 'Dividir PDF',
      icon: '✂️',
      description: 'Separa páginas individuales',
      price: 'Gratuito',
      category: 'edit'
    },
    rotate: {
      name: 'Rotar Páginas',
      icon: '🔄',
      description: '90°, 180°, 270°',
      price: 'Gratuito',
      category: 'edit'
    },
    watermark: {
      name: 'Añadir Marca',
      icon: '💧',
      description: 'Texto o imagen de fondo',
      price: 'Gratuito',
      category: 'edit'
    },
    extractText: {
      name: 'Extraer Texto',
      icon: '📖',
      description: 'Obtén todo el contenido',
      price: 'Gratuito',
      category: 'convert'
    },
    toImages: {
      name: 'PDF a Imágenes',
      icon: '🖼️',
      description: 'JPG, PNG, WebP por página',
      price: 'Pro',
      category: 'convert'
    },
    toWord: {
      name: 'PDF a Word',
      icon: '📝',
      description: 'Editable .docx con IA',
      price: 'Pro',
      category: 'convert'
    },
    toExcel: {
      name: 'PDF a Excel',
      icon: '📊',
      description: 'Tablas automáticas',
      price: 'Pro',
      category: 'convert'
    },
    toPowerPoint: {
      name: 'PDF a PowerPoint',
      icon: '🎯',
      description: 'Diapositivas automáticas',
      price: 'Business',
      category: 'convert'
    },
    toHTML: {
      name: 'PDF a HTML',
      icon: '🌐',
      description: 'Responsive web version',
      price: 'Pro',
      category: 'convert'
    },
    toMarkdown: {
      name: 'PDF a Markdown',
      icon: '📋',
      description: 'Formato Markdown puro',
      price: 'Pro',
      category: 'convert'
    },
    ocr: {
      name: 'OCR + IA',
      icon: '👁️',
      description: 'Escanea y reconoce 40 idiomas',
      price: 'Pro',
      category: 'advanced'
    },
    protect: {
      name: 'Proteger PDF',
      icon: '🔒',
      description: 'Contraseña AES-256',
      price: 'Pro',
      category: 'security'
    },
    unlock: {
      name: 'Desbloquear PDF',
      icon: '🔓',
      description: 'Quita restricciones',
      price: 'Business',
      category: 'security'
    },
    fillForm: {
      name: 'Rellenar Formularios',
      icon: '📋',
      description: 'Auto-complete con IA',
      price: 'Pro',
      category: 'advanced'
    },
    editor: {
      name: 'Editor Visual',
      icon: '✏️',
      description: 'WYSIWYG completo',
      price: 'Business',
      category: 'edit'
    },
    batchProcess: {
      name: 'Procesamiento Batch',
      icon: '⚡',
      description: '1000+ PDFs paralelos',
      price: 'Business',
      category: 'advanced'
    }
  },

  // E-Signature (eIDAS)
  signature: {
    request: {
      name: 'Solicitar Firmas',
      icon: '📝',
      description: 'Email a múltiples firmantes',
      price: 'Pro',
      category: 'signature'
    },
    draw: {
      name: 'Firma Manuscrita',
      icon: '✍️',
      description: 'Dibuja tu firma',
      price: 'Pro',
      category: 'signature'
    },
    certificate: {
      name: 'Firma Certificada',
      icon: '🎖️',
      description: 'eIDAS Nivel 2 (legal)',
      price: 'Business',
      category: 'signature'
    },
    batch: {
      name: 'Firmas Múltiples',
      icon: '📋',
      description: 'Lotes de documentos',
      price: 'Business',
      category: 'signature'
    },
    verify: {
      name: 'Verificar Firma',
      icon: '✅',
      description: 'Valida autenticidad',
      price: 'Pro',
      category: 'signature'
    },
    timestamp: {
      name: 'Sello de Tiempo',
      icon: '⏱️',
      description: 'Prueba de integridad',
      price: 'Business',
      category: 'signature'
    }
  },

  // Advanced AI
  advanced: {
    contractAnalysis: {
      name: 'Análisis de Contratos',
      icon: '⚖️',
      description: 'Identifica riesgos y términos',
      tokens: 2500,
      price: 'Business',
      category: 'ai'
    },
    invoiceProcessor: {
      name: 'Procesador de Facturas',
      icon: '🧾',
      description: 'Auto-extrae datos',
      tokens: 1500,
      price: 'Business',
      category: 'ai'
    },
    complianceCheck: {
      name: 'Verificador de Compliance',
      icon: '⚖️',
      description: 'GDPR, HIPAA, CCPA',
      tokens: 2000,
      price: 'Business',
      category: 'ai'
    },
    bulkProcessing: {
      name: 'Procesamiento Masivo',
      icon: '📦',
      description: 'Miles de PDFs automáticos',
      tokens: 'variable',
      price: 'Agencia',
      category: 'ai'
    },
    apiAccess: {
      name: 'API REST Completa',
      icon: '🔗',
      description: 'Integración en tu app',
      price: 'Business',
      category: 'api'
    }
  }
};

// Count total features
const totalFeatures = Object.values(FEATURES)
  .reduce((sum, category) => sum + Object.keys(category).length, 0);

console.log(`✅ ${totalFeatures}+ features loaded`);

export default FEATURES;
