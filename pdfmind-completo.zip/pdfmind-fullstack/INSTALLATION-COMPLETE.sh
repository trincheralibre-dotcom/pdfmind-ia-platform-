#!/bin/bash

####################################################################
#                                                                  #
#  🚀 PDFMind IA v2.0 - AUTOMATIC INSTALLATION & CONFIGURATION  #
#                                                                  #
####################################################################

set -e

echo "╔════════════════════════════════════════════════════════════════╗"
echo "║                                                                ║"
echo "║     🚀 PDFMind IA - Installation & Configuration Script      ║"
echo "║                                                                ║"
echo "╚════════════════════════════════════════════════════════════════╝"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

#################################################################
# STEP 1: CHECK REQUIREMENTS
#################################################################

echo -e "\n${BLUE}[1/8] Checking system requirements...${NC}"

check_command() {
    if ! command -v $1 &> /dev/null; then
        echo -e "${RED}✗ $1 is required but not installed.${NC}"
        echo -e "${YELLOW}Install it and try again.${NC}"
        exit 1
    else
        echo -e "${GREEN}✓ $1 found${NC}"
    fi
}

check_command "node"
check_command "npm"
check_command "git"

NODE_VERSION=$(node -v)
NPM_VERSION=$(npm -v)

echo -e "${GREEN}✓ Node.js ${NODE_VERSION}${NC}"
echo -e "${GREEN}✓ npm ${NPM_VERSION}${NC}"

#################################################################
# STEP 2: INSTALL DEPENDENCIES
#################################################################

echo -e "\n${BLUE}[2/8] Installing backend dependencies...${NC}"

cd backend

npm install --save-exact \
    express@4.18.2 \
    express-validator@7.0.0 \
    helmet@7.0.0 \
    express-rate-limit@6.7.0 \
    cors@2.8.5 \
    dotenv@16.0.3 \
    jsonwebtoken@9.0.0 \
    bcryptjs@2.4.3 \
    firebase@9.23.0 \
    stripe@12.0.0 \
    nodemailer@6.9.3 \
    multer@1.4.5-lts.1 \
    pdfkit@0.13.0 \
    sharp@0.32.0 \
    tesseract.js@4.1.1 \
    pdf-parse@1.1.1 \
    mammoth@1.6.0 \
    xlsx@0.18.5 \
    @anthropic-ai/sdk@0.7.1

echo -e "${GREEN}✓ Backend dependencies installed${NC}"

#################################################################
# STEP 3: CONFIGURE ENVIRONMENT
#################################################################

echo -e "\n${BLUE}[3/8] Setting up environment variables...${NC}"

if [ ! -f .env ]; then
    cat > .env << 'ENVEOF'
# Server Configuration
PORT=5000
NODE_ENV=development
API_URL=http://localhost:5000
ALLOWED_ORIGINS=http://localhost:3000,http://localhost:5000

# Firebase Configuration
FIREBASE_API_KEY=your_firebase_api_key
FIREBASE_AUTH_DOMAIN=your_project.firebaseapp.com
FIREBASE_PROJECT_ID=your_project_id
FIREBASE_STORAGE_BUCKET=your_project.appspot.com
FIREBASE_MESSAGING_SENDER_ID=your_sender_id
FIREBASE_APP_ID=your_app_id
FIREBASE_SERVICE_ACCOUNT_KEY={}

# Stripe Configuration
STRIPE_SECRET_KEY=sk_test_your_key_here
STRIPE_PUBLISHABLE_KEY=pk_test_your_key_here
STRIPE_WEBHOOK_SECRET=whsec_your_webhook_secret

# Anthropic/Claude Configuration
ANTHROPIC_API_KEY=sk-ant-your_api_key_here

# Email Configuration
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USER=your_email@gmail.com
EMAIL_PASS=your_app_password
EMAIL_FROM=noreply@pdfmind.ai

# JWT Configuration
JWT_SECRET=your_jwt_secret_key_change_this_in_production
JWT_EXPIRY=30d

# Cloudinary Configuration (optional, for image storage)
CLOUDINARY_NAME=your_cloudinary_name
CLOUDINARY_API_KEY=your_api_key
CLOUDINARY_API_SECRET=your_api_secret

# Sentry Configuration (optional, for error tracking)
SENTRY_DSN=your_sentry_dsn

# Database
DATABASE_URL=your_database_url
ENVEOF

    echo -e "${GREEN}✓ .env file created${NC}"
    echo -e "${YELLOW}⚠ Please configure your credentials in .env${NC}"
else
    echo -e "${GREEN}✓ .env already exists${NC}"
fi

cd ..

#################################################################
# STEP 4: SETUP FRONTEND
#################################################################

echo -e "\n${BLUE}[4/8] Setting up frontend...${NC}"

if [ ! -f frontend/config.js ]; then
    mkdir -p frontend
    
    cat > frontend/config.js << 'CONFIGEOF'
// Frontend Configuration
const config = {
  API_URL: 'http://localhost:5000/api',
  NODE_ENV: 'development',
  STRIPE_PUBLIC_KEY: 'pk_test_your_key_here',
  FIREBASE_CONFIG: {
    apiKey: 'your_firebase_api_key',
    authDomain: 'your_project.firebaseapp.com',
    projectId: 'your_project_id',
    storageBucket: 'your_project.appspot.com',
    messagingSenderId: 'your_sender_id',
    appId: 'your_app_id'
  }
};

// Export for use
if (typeof module !== 'undefined' && module.exports) {
  module.exports = config;
}
CONFIGEOF

    echo -e "${GREEN}✓ Frontend config created${NC}"
fi

#################################################################
# STEP 5: CREATE DATABASE COLLECTIONS
#################################################################

echo -e "\n${BLUE}[5/8] Database structure (Firebase)...${NC}"

cat > backend/firebase-init.js << 'FIREBASEEOF'
/**
 * Firebase Initialization & Collections Setup
 */

const admin = require('firebase-admin');

const serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_KEY || '{}');

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount)
});

const db = admin.firestore();

// Create collections with sample documents
const initializeDatabase = async () => {
  try {
    // Users collection
    console.log('Initializing Users collection...');
    await db.collection('users').doc('example').set({
      email: 'example@pdfmind.ai',
      name: 'Example User',
      plan: 'pro',
      created_at: admin.firestore.FieldValue.serverTimestamp(),
      updated_at: admin.firestore.FieldValue.serverTimestamp()
    });

    // Files collection
    console.log('Initializing Files collection...');
    await db.collection('files').doc('example').set({
      user_id: 'example',
      filename: 'example.pdf',
      size: 1024000,
      created_at: admin.firestore.FieldValue.serverTimestamp()
    });

    // Chats collection
    console.log('Initializing Chats collection...');
    await db.collection('chats').doc('example').set({
      user_id: 'example',
      pdf_id: 'example',
      messages: [],
      created_at: admin.firestore.FieldValue.serverTimestamp()
    });

    // Invoices collection
    console.log('Initializing Invoices collection...');
    await db.collection('invoices').doc('example').set({
      user_id: 'example',
      invoice_number: 'INV-2026-001',
      amount: 900,
      status: 'paid',
      created_at: admin.firestore.FieldValue.serverTimestamp()
    });

    // Signatures collection
    console.log('Initializing Signatures collection...');
    await db.collection('signatures').doc('example').set({
      user_id: 'example',
      pdf_id: 'example',
      status: 'pending',
      signers: [],
      created_at: admin.firestore.FieldValue.serverTimestamp()
    });

    console.log('✓ Database initialized successfully');
  } catch (error) {
    console.error('Error initializing database:', error);
  }
};

module.exports = { initializeDatabase, db, admin };
FIREBASEEOF

echo -e "${GREEN}✓ Database initialization file created${NC}"

#################################################################
# STEP 6: CREATE SYSTEMD SERVICE (optional)
#################################################################

echo -e "\n${BLUE}[6/8] Creating service configuration...${NC}"

if [ "$EUID" -eq 0 ]; then
    cat > /etc/systemd/system/pdfmind.service << 'SERVICEEOF'
[Unit]
Description=PDFMind IA Service
After=network.target

[Service]
Type=simple
User=www-data
WorkingDirectory=/opt/pdfmind
ExecStart=/usr/bin/node /opt/pdfmind/backend/server.js
Restart=on-failure
RestartSec=10

[Install]
WantedBy=multi-user.target
SERVICEEOF

    systemctl daemon-reload
    echo -e "${GREEN}✓ Systemd service created${NC}"
    echo -e "${YELLOW}   To start: systemctl start pdfmind${NC}"
else
    echo -e "${YELLOW}⚠ Skipping systemd service (requires root)${NC}"
fi

#################################################################
# STEP 7: CREATE DEPLOYMENT FILES
#################################################################

echo -e "\n${BLUE}[7/8] Creating deployment files...${NC}"

# Vercel configuration
cat > backend/vercel.json << 'VERCELEOF'
{
  "version": 2,
  "builds": [
    {
      "src": "server.js",
      "use": "@vercel/node"
    }
  ],
  "routes": [
    {
      "src": "/(.*)",
      "dest": "server.js"
    }
  ],
  "env": {
    "NODE_ENV": "production"
  }
}
VERCELEOF

# Docker configuration
cat > Dockerfile << 'DOCKEREOF'
FROM node:18-alpine

WORKDIR /app

COPY backend/package*.json ./
RUN npm install

COPY backend/ .

EXPOSE 5000

CMD ["node", "server.js"]
DOCKEREOF

# Docker Compose
cat > docker-compose.yml << 'COMPOSEEOF'
version: '3.8'

services:
  pdfmind-backend:
    build: .
    ports:
      - "5000:5000"
    environment:
      - NODE_ENV=production
      - PORT=5000
    volumes:
      - ./backend:/app
    restart: unless-stopped

  pdfmind-frontend:
    image: node:18-alpine
    working_dir: /app
    ports:
      - "3000:3000"
    volumes:
      - ./frontend:/app
    command: npm start
    restart: unless-stopped
COMPOSEEOF

echo -e "${GREEN}✓ Deployment files created${NC}"

#################################################################
# STEP 8: FINAL SUMMARY
#################################################################

echo -e "\n${BLUE}[8/8] Installation complete!${NC}\n"

echo -e "${GREEN}════════════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}✓ PDFMind IA Installation Successfully Completed!${NC}"
echo -e "${GREEN}════════════════════════════════════════════════════════════════${NC}\n"

echo -e "${YELLOW}NEXT STEPS:${NC}\n"

echo -e "1. ${BLUE}Configure your credentials:${NC}"
echo -e "   nano backend/.env"
echo -e "   - Add Firebase keys"
echo -e "   - Add Stripe keys"
echo -e "   - Add Anthropic API key"
echo -e "   - Add Email credentials\n"

echo -e "2. ${BLUE}Initialize the database:${NC}"
echo -e "   cd backend"
echo -e "   node firebase-init.js\n"

echo -e "3. ${BLUE}Start development server:${NC}"
echo -e "   cd backend"
echo -e "   npm run dev\n"

echo -e "4. ${BLUE}Start frontend:${NC}"
echo -e "   # In another terminal"
echo -e "   cd frontend"
echo -e "   npm start\n"

echo -e "5. ${BLUE}Test the API:${NC}"
echo -e "   curl http://localhost:5000/api/health\n"

echo -e "6. ${BLUE}Deploy to production:${NC}"
echo -e "   vercel --prod\n"

echo -e "${GREEN}Documentation:${NC}"
echo -e "  - API Docs: http://localhost:5000/api/docs"
echo -e "  - Dashboard: http://localhost:3000"
echo -e "  - Support: support@pdfmind.ai\n"

echo -e "${YELLOW}Important reminders:${NC}"
echo -e "  • Never commit .env file to git"
echo -e "  • Use strong JWT_SECRET in production"
echo -e "  • Enable HTTPS in production"
echo -e "  • Set up SSL certificates"
echo -e "  • Configure rate limiting for APIs"
echo -e "  • Set up monitoring and error tracking\n"

echo -e "${GREEN}You're all set! Let's dominate the PDF market! 🚀${NC}\n"
